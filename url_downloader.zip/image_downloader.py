# -*- coding: utf-8 -*-
import csv
from multiprocessing.pool import ThreadPool
import os
import json
import requests
import time

with open('config.json') as o:
    config = json.load(o)
    urls_file = config['csv_file']
    path = config['download_path']
    concurrent_requests = config['concurrent_requests']

start = time.time()


def get_download_location():
    dir_name = path  # 设置文件夹的名字
    if not os.path.exists(dir_name):  # os模块判断并创建
        os.mkdir(dir_name)
    return path


def get_urls():
    with open(urls_file, 'r') as f:
        reader = csv.reader(f)
        images_url = []
        for row in reader:
            images_url.append(row[0])
    print('{} Images detected'.format(len(images_url)))
    return images_url


def image_downloader(img_url: str):
    print(f'Downloading: {img_url}')
    res = requests.get(img_url, stream=True)
    picture_name = img_url.split('/')[-1]
    image = res.content
    with open(path + '/' + picture_name, 'wb') as f:
        f.write(image)
    return f'Download complete: {img_url}'


def run_downloader(process: int, images_url: list):
    print(f'MESSAGE: Running {process} process')
    results = ThreadPool(process).imap_unordered(image_downloader, images_url)
    for r in results:
        print(r)


try:
    num_process = concurrent_requests

except:
    num_process = 10

image_location = get_download_location()
images_url = get_urls()
run_downloader(num_process, images_url)

end = time.time()
print('Time taken to download {}'.format(len(get_urls())))
print(end - start)
