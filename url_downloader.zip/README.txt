config.json文件可以通过修改“csv_file”配置csv文件的路径，修改“download_path”下载文件夹的路径，修改“concurrents_requests”修改并发的数量
双击image_dowloader.py文件即可运行，运行环境python3.9，运行前确保安装requrements.txt里的包。
csv文件用记事本打开->另存为->编码选择ANSI可解决运行脚本闪退问题。
The config.json file can configure the path of the csv file by modifying the "csv_file", modify the path of the "download_path" download folder, and modify the number of concurrent requests
Double-click image_ The dowloader.py file can be run in python3.9. Make sure to install the package in requirements.txt before running.
Open the csv file with Notepad ->Save as ->Encode ANSI to solve the problem of running script flashback.